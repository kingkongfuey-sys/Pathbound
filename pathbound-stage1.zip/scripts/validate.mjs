// Stage 1 validator: checks the app's own copy against the voice rules, so tone drift is caught
// at build time rather than by eye. Content/schema validation joins this in Stage 2.
import { readFileSync } from 'node:fs';

const file = new URL('../src/copy/voice.ts', import.meta.url);
const source = readFileSync(file, 'utf-8');

// Every quoted or template string literal in voice.ts is UI copy (the file holds nothing else quoted).
const strings = [...source.matchAll(/'((?:[^'\\]|\\.)*)'|`((?:[^`\\]|\\.)*)`/g)].map((m) => m[1] ?? m[2] ?? '');
const copy = strings.filter((s) => /\s/.test(s) || /^[A-Z]/.test(s));

const bannedPhrases = ['welcome', 'loading', 'oops', 'tap to continue', 'something went wrong', 'please wait'];
const emoji = /\p{Extended_Pictographic}/u;

const problems = [];
for (const text of copy) {
  if (text.includes('!')) problems.push(`exclamation mark in: "${text}"`);
  if (emoji.test(text)) problems.push(`emoji in: "${text}"`);
  if (text.includes("\\'") || /\w'\w/.test(text)) problems.push(`straight apostrophe (use ’) in: "${text}"`);
  for (const phrase of bannedPhrases) {
    if (text.toLowerCase().includes(phrase)) problems.push(`banned phrase "${phrase}" in: "${text}"`);
  }
}

if (problems.length > 0) {
  console.error('Voice check failed:');
  for (const p of problems) console.error(`  - ${p}`);
  process.exit(1);
}
console.log(`Voice check passed (${copy.length} strings read).`);
