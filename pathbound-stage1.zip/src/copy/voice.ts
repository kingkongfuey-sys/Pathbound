// Every word the app's own chrome says, in one place, in the Weary Chronicler's voice.
// Story prose never lives here (it belongs to content files); this is only the app talking.
// Voice rules: dry, tired, quietly fond. Plain sentences, no exclamation marks, no emoji,
// no "welcome", no "loading", no apologies. Run `npm run validate` after editing; it checks these.

export const voice = {
  home: {
    title: 'Pathbound',
    epigraph: 'I keep the record. You supply the misfortune.',
    newRun: 'Begin an entry',
    ledger: 'The ledger',
    version: (v: string): string => `Version ${v}`,
  },
  shelf: {
    heading: 'Begin an entry',
    empty: 'The shelf is bare. The first tale hasn’t been set down yet.',
    emptyHint: 'Come back once it has.',
  },
  ledger: {
    heading: 'The ledger',
    empty: 'The ledger is bare. Go and give me something to write.',
  },
  nav: {
    back: 'Back to the desk',
  },
  fatal: {
    heading: 'The page won’t turn',
    lead: 'Something in the record is broken. This is what it says:',
    unknown: 'It says nothing useful, which is its own kind of answer.',
  },
} as const;
