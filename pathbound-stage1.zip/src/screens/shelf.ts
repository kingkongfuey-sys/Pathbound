// Story shelf: where a new run begins by choosing a story. With no stories on disk it says so plainly.
import type { Navigator } from '../app/router';
import { voice } from '../copy/voice';
import { el } from '../ui/dom';
import { backLink, page, pageHead } from '../ui/page';

export function shelfScreen(nav: Navigator): HTMLElement {
  return page(
    backLink(nav),
    pageHead(voice.shelf.heading),
    el('p', 'prose', voice.shelf.empty),
    el('p', 'prose prose-quiet', voice.shelf.emptyHint),
  );
}
