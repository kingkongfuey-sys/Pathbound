// A deliberately small screen stack. Screens are builder functions; showing one replaces
// the whole page. A stack (not URLs) because the app is touch-only and has exactly one
// "back" meaning, shared by the on-screen back link and the Android back button.

export type ScreenBuilder = (nav: Navigator) => HTMLElement;

export class Navigator {
  private readonly stack: ScreenBuilder[] = [];

  constructor(private readonly root: HTMLElement) {}

  push(build: ScreenBuilder): void {
    this.stack.push(build);
    this.show();
  }

  /** Go back one screen. Returns false when already on the first screen (nothing to pop). */
  pop(): boolean {
    if (this.stack.length <= 1) return false;
    this.stack.pop();
    this.show();
    return true;
  }

  private show(): void {
    const build = this.stack[this.stack.length - 1];
    if (!build) return;
    this.root.replaceChildren(build(this));
    window.scrollTo(0, 0);
  }
}
